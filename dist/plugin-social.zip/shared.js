"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.execFileAsync = void 0;
exports.formatUnixTimestamp = formatUnixTimestamp;
const child_process_1 = require("child_process");
const util_1 = require("util");
exports.execFileAsync = (0, util_1.promisify)(child_process_1.execFile);
// =============================================================================
// Shared Utilities
// =============================================================================
function formatUnixTimestamp(utc) {
    return new Date(utc * 1000).toISOString();
}
