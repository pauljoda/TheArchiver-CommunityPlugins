"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.REDDIT_ACCOUNT_SLOT_COUNT = exports.execFileAsync = void 0;
exports.redditAccountCachedCookiesPath = redditAccountCachedCookiesPath;
exports.formatUnixTimestamp = formatUnixTimestamp;
exports.sanitizeRelativeFolder = sanitizeRelativeFolder;
exports.redditAccountDisplayName = redditAccountDisplayName;
exports.loadRedditAccountSlots = loadRedditAccountSlots;
exports.findRedditAccountByUsername = findRedditAccountByUsername;
exports.buildCookieHeaderFromContent = buildCookieHeaderFromContent;
exports.buildCookieHeaderFromFile = buildCookieHeaderFromFile;
exports.redditAccountCookiesBlobKey = redditAccountCookiesBlobKey;
exports.resolveRedditCookieHeader = resolveRedditCookieHeader;
const child_process_1 = require("child_process");
const util_1 = require("util");
const fs_1 = __importDefault(require("fs"));
const os_1 = __importDefault(require("os"));
const path_1 = __importDefault(require("path"));
exports.execFileAsync = (0, util_1.promisify)(child_process_1.execFile);
// =============================================================================
// Plugin Cache Directory
// =============================================================================
//
// The host app's `type: "file"` setting storage is opaque and, per user
// report, can lose uploaded files between reboots. To make cookies survive
// those restarts, plugin-social snapshots each successfully-read cookies.txt
// into its own cache under the user's home directory and falls back to the
// snapshot when the host-provided path is gone.
const PLUGIN_CACHE_ROOT = path_1.default.join(os_1.default.homedir(), ".thearchiver", "plugin-social");
function redditAccountCachedCookiesPath(slot) {
    return path_1.default.join(PLUGIN_CACHE_ROOT, "accounts", `account-${slot}-cookies.txt`);
}
// =============================================================================
// Shared Utilities
// =============================================================================
function formatUnixTimestamp(utc) {
    return new Date(utc * 1000).toISOString();
}
// =============================================================================
// Reddit Account Slots
// =============================================================================
/**
 * The plugin pre-declares a fixed number of Reddit account slots. Each slot
 * stores a username and a cookies.txt file; download handlers look up the
 * matching account by username (case-insensitive) when a URL like
 * /user/<name>/upvoted comes in.
 *
 * Increasing this number is safe — add matching settings in index.ts and
 * manifest.json, and actions in the plugin's `actions` block.
 */
exports.REDDIT_ACCOUNT_SLOT_COUNT = 5;
/**
 * Sanitises a user-provided relative folder path for use as a download
 * destination. Returns the cleaned value, or "" if the input is empty,
 * absolute, or contains path-traversal segments. Normalises separators to
 * "/" so `path.join(root, value)` always produces a child of `root` on any
 * platform.
 */
function sanitizeRelativeFolder(input) {
    const raw = (input || "").trim();
    if (!raw)
        return "";
    // Reject absolute paths up front, BEFORE any normalisation. Leading
    // slash = POSIX absolute; `C:/...` or `\\server\share` = Windows absolute.
    // We deliberately do NOT silently strip the leading slash — a user who
    // types "/etc/passwd" is clearly not asking for a relative path.
    if (/^[/\\]/.test(raw))
        return "";
    if (/^[a-zA-Z]:[/\\]/.test(raw))
        return "";
    // Now safe to strip trailing separators and collapse runs.
    const trimmed = raw.replace(/[/\\]+$/g, "");
    if (!trimmed)
        return "";
    const segments = trimmed.split(/[/\\]+/);
    if (segments.some((seg) => seg === ".." || seg === "."))
        return "";
    return segments.join("/");
}
/**
 * Returns the effective display name for an account — verified if we have one,
 * otherwise the user-entered username, otherwise an empty string.
 */
function redditAccountDisplayName(account) {
    return account.verifiedUsername || account.configuredUsername || "";
}
/** Reads all N account slots from settings, including empty ones. */
function loadRedditAccountSlots(settings) {
    const slots = [];
    for (let i = 1; i <= exports.REDDIT_ACCOUNT_SLOT_COUNT; i++) {
        slots.push({
            slot: i,
            configuredUsername: (settings.get(`reddit_account_${i}_username`) || "").trim(),
            verifiedUsername: (settings.get(`reddit_account_${i}_verified_username`) || "").trim(),
            cookiesFile: (settings.get(`reddit_account_${i}_cookies_file`) || "").trim(),
            upvotedFolder: sanitizeRelativeFolder(settings.get(`reddit_account_${i}_upvoted_folder`) || ""),
        });
    }
    return slots;
}
/**
 * Finds the first configured account that matches the given Reddit username
 * (case-insensitive). Returns null if no slot's name matches. A slot is a
 * match as long as its name is set — whether cookies are actually resolvable
 * is decided later by {@link resolveRedditCookieHeader}, which also consults
 * the plugin's on-disk cache. That way a slot whose `cookies_file` setting
 * got wiped at reboot still matches as long as a cached snapshot exists.
 */
function findRedditAccountByUsername(settings, username) {
    const target = username.trim().toLowerCase();
    if (!target)
        return null;
    for (const slot of loadRedditAccountSlots(settings)) {
        const name = redditAccountDisplayName(slot).toLowerCase();
        if (!name)
            continue;
        if (name === target)
            return slot;
    }
    return null;
}
// =============================================================================
// Reddit Cookie Helper (Netscape cookies.txt format)
// =============================================================================
/**
 * Parses a Netscape-format cookies.txt text buffer and returns a `Cookie`
 * header value containing only cookies scoped to reddit.com. Returns null if
 * the buffer contains no reddit.com cookies.
 *
 * Netscape format columns (tab-separated):
 *   domain \t includeSubdomains \t path \t secure \t expires \t name \t value
 */
function buildCookieHeaderFromContent(text) {
    const pairs = [];
    for (const rawLine of text.split(/\r?\n/)) {
        const line = rawLine.trim();
        if (!line)
            continue;
        // Netscape format allows "#HttpOnly_" prefix lines; strip it and still parse.
        const parseLine = line.startsWith("#HttpOnly_") ? line.slice(10) : line;
        if (parseLine.startsWith("#"))
            continue;
        const parts = parseLine.split("\t");
        if (parts.length < 7)
            continue;
        const domain = parts[0];
        const name = parts[5];
        const value = parts[6];
        if (!domain || !name)
            continue;
        const bareDomain = domain.replace(/^\./, "").toLowerCase();
        if (bareDomain !== "reddit.com" && !bareDomain.endsWith(".reddit.com")) {
            continue;
        }
        pairs.push(`${name}=${value}`);
    }
    return pairs.length > 0 ? pairs.join("; ") : null;
}
/**
 * Reads a Netscape-format cookies.txt file and returns a `Cookie` header value
 * containing only cookies scoped to reddit.com. Returns null if the file is
 * missing, unreadable, or contains no reddit.com cookies.
 */
function buildCookieHeaderFromFile(filePath) {
    if (!filePath)
        return null;
    try {
        if (!fs_1.default.existsSync(filePath))
            return null;
        const text = fs_1.default.readFileSync(filePath, "utf8");
        return buildCookieHeaderFromContent(text);
    }
    catch {
        return null;
    }
}
function redditAccountCookiesBlobKey(slot) {
    return `reddit_account_${slot}_cookies_blob`;
}
/**
 * Resolves cookies for a Reddit account slot in a reboot-resilient way.
 *
 * Why this matters: the host's `type: "file"` setting storage is not always
 * persistent — in the Dockerised deployment the uploaded cookies.txt lives
 * on the container's writable layer and disappears on recreate. So as soon
 * as we successfully read a live file we stash its contents into a hidden
 * *string* setting (which IS persistent in the host DB) and ALSO into a
 * local filesystem cache for native installs.
 *
 * Resolution order:
 *   1. Live file at `userPickedPath` — authoritative whenever present.
 *   2. Hidden string setting `reddit_account_<slot>_cookies_blob` — persists
 *      across Docker container restarts because it lives in the host DB.
 *   3. Filesystem snapshot under `~/.thearchiver/plugin-social/accounts/` —
 *      legacy layer, only useful on native hosts where `os.homedir()` is
 *      both stable and writable (doesn't help in a container where HOME is
 *      the ephemeral writable layer).
 *
 * Never throws. Best-effort caching failures are logged via `logger.warn`
 * but don't block returning a valid header.
 */
async function resolveRedditCookieHeader(slot, userPickedPath, settings, logger) {
    const cachePath = redditAccountCachedCookiesPath(slot);
    const blobKey = redditAccountCookiesBlobKey(slot);
    // 1. Try the user-picked (host-provided) path first
    if (userPickedPath && fs_1.default.existsSync(userPickedPath)) {
        try {
            const content = fs_1.default.readFileSync(userPickedPath, "utf8");
            const header = buildCookieHeaderFromContent(content);
            if (header) {
                // Primary snapshot: hidden string setting (persistent in host DB,
                // survives Docker container recreates).
                try {
                    await settings.set(blobKey, content);
                }
                catch (err) {
                    logger?.warn?.(`Reddit account ${slot}: failed to snapshot cookies to setting ${blobKey}: ${err instanceof Error ? err.message : String(err)}`);
                }
                // Secondary snapshot: filesystem cache (legacy, native-only).
                try {
                    fs_1.default.mkdirSync(path_1.default.dirname(cachePath), { recursive: true });
                    fs_1.default.writeFileSync(cachePath, content, "utf8");
                    try {
                        fs_1.default.chmodSync(cachePath, 0o600);
                    }
                    catch {
                        /* best-effort; non-POSIX filesystems may not honor chmod */
                    }
                }
                catch (err) {
                    logger?.warn?.(`Reddit account ${slot}: failed to snapshot cookies to fs cache (${cachePath}): ${err instanceof Error ? err.message : String(err)}`);
                }
                return {
                    cookieHeader: header,
                    resolvedFrom: "live",
                    sourcePath: userPickedPath,
                };
            }
        }
        catch (err) {
            logger?.warn?.(`Reddit account ${slot}: failed to read user-picked cookies file at ${userPickedPath}: ${err instanceof Error ? err.message : String(err)}`);
        }
    }
    // 2. Fall back to the hidden setting blob (Docker-friendly)
    const blobContent = (settings.get(blobKey) || "").toString();
    if (blobContent) {
        const header = buildCookieHeaderFromContent(blobContent);
        if (header) {
            logger?.info?.(`Reddit account ${slot}: using cookies from hidden setting blob (${blobKey}); host-provided file missing or unreadable`);
            return {
                cookieHeader: header,
                resolvedFrom: "setting-blob",
                sourcePath: `setting:${blobKey}`,
            };
        }
    }
    // 3. Fall back to the filesystem snapshot (legacy)
    if (fs_1.default.existsSync(cachePath)) {
        try {
            const content = fs_1.default.readFileSync(cachePath, "utf8");
            const header = buildCookieHeaderFromContent(content);
            if (header) {
                logger?.info?.(`Reddit account ${slot}: using fs cache snapshot at ${cachePath} (host file and setting blob both unavailable)`);
                // Opportunistically promote the legacy cache into the setting blob
                // so next time we can skip straight to the Docker-friendly path.
                try {
                    await settings.set(blobKey, content);
                }
                catch {
                    /* best-effort */
                }
                return {
                    cookieHeader: header,
                    resolvedFrom: "cache",
                    sourcePath: cachePath,
                };
            }
        }
        catch (err) {
            logger?.warn?.(`Reddit account ${slot}: fs cache snapshot at ${cachePath} is unreadable: ${err instanceof Error ? err.message : String(err)}`);
        }
    }
    return null;
}
