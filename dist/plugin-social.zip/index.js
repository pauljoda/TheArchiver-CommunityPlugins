"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const reddit_1 = require("./reddit");
const bluesky_1 = require("./bluesky");
const twitter_1 = require("./twitter");
// =============================================================================
// Plugin Definition
// =============================================================================
const plugin = {
    name: "Socials",
    version: "1.0.0",
    description: "Download images, galleries, and metadata from social media platforms",
    urlPatterns: [
        "https://reddit.com",
        "https://www.reddit.com",
        "https://old.reddit.com",
        "https://bsky.app",
        "https://x.com",
        "https://twitter.com",
        "https://www.twitter.com",
        "https://mobile.twitter.com",
    ],
    settings: [
        {
            key: "save_directory",
            type: "string",
            label: "Save Directory",
            description: "Base folder name for saved social media content within the root directory",
            required: false,
            defaultValue: "Socials",
            sortOrder: 0,
        },
        {
            key: "reddit_subfolder",
            type: "string",
            label: "Reddit Subfolder",
            description: "Subfolder name for Reddit content within the save directory",
            required: false,
            defaultValue: "Reddit",
            sortOrder: 1,
        },
        {
            key: "subreddit_sort",
            type: "select",
            label: "Subreddit Sort",
            description: "Sort order when downloading from a subreddit",
            defaultValue: "hot",
            validation: {
                options: [
                    { label: "Hot", value: "hot" },
                    { label: "New", value: "new" },
                    { label: "Top", value: "top" },
                    { label: "Rising", value: "rising" },
                ],
            },
            sortOrder: 2,
        },
        {
            key: "subreddit_time_filter",
            type: "select",
            label: "Top Posts Time Filter",
            description: "Time range when sorting by 'top'",
            defaultValue: "all",
            validation: {
                options: [
                    { label: "Past Hour", value: "hour" },
                    { label: "Past 24 Hours", value: "day" },
                    { label: "Past Week", value: "week" },
                    { label: "Past Month", value: "month" },
                    { label: "Past Year", value: "year" },
                    { label: "All Time", value: "all" },
                ],
            },
            sortOrder: 3,
        },
        {
            key: "subreddit_post_count",
            type: "number",
            label: "Reddit Posts to Download",
            description: "Number of posts to fetch from subreddits/profiles. -1 for max (~1000, Reddit limit)",
            defaultValue: "100",
            sortOrder: 4,
        },
        {
            key: "save_metadata",
            type: "boolean",
            label: "Save Metadata",
            description: "Save post metadata (Post.nfo) and comments (Comments.json) alongside media files",
            defaultValue: "true",
            sortOrder: 5,
        },
        {
            key: "bluesky_subfolder",
            type: "string",
            label: "Bluesky Subfolder",
            description: "Subfolder name for Bluesky content within the save directory",
            required: false,
            defaultValue: "Bluesky",
            sortOrder: 10,
        },
        {
            key: "bluesky_post_count",
            type: "number",
            label: "Bluesky Posts to Download",
            description: "Number of posts to fetch from a Bluesky profile. -1 for all available posts",
            defaultValue: "100",
            sortOrder: 11,
        },
        {
            key: "twitter_subfolder",
            type: "string",
            label: "Twitter/X Subfolder",
            description: "Subfolder name for Twitter/X content within the save directory",
            required: false,
            defaultValue: "Twitter",
            sortOrder: 20,
        },
    ],
    async download(context) {
        const { url } = context;
        // Try Reddit first
        if ((0, reddit_1.parseRedditUrl)(url)) {
            return await (0, reddit_1.downloadReddit)(context);
        }
        // Try Bluesky
        if ((0, bluesky_1.parseBlueskyUrl)(url)) {
            return await (0, bluesky_1.downloadBluesky)(context);
        }
        // Try Twitter/X
        if ((0, twitter_1.parseTwitterUrl)(url)) {
            return await (0, twitter_1.downloadTwitter)(context);
        }
        return {
            success: false,
            message: "URL not recognized. Supported formats: reddit.com/r/.../comments/..., reddit.com/u/..., reddit.com/r/..., bsky.app/profile/{handle}, bsky.app/profile/{handle}/post/{id}, x.com/{user}/status/{id}",
        };
    },
};
exports.default = plugin;
