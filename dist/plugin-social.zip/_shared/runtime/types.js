"use strict";
// ╔═══════════════════════════════════════════════════════════════════╗
// ║  DO NOT EDIT — this file is synced from                           ║
// ║  plugins/_shared/runtime/types.ts                                 ║
// ║  by scripts/sync-shared.mjs. Edit the source, not this copy.      ║
// ╚═══════════════════════════════════════════════════════════════════╝
Object.defineProperty(exports, "__esModule", { value: true });
