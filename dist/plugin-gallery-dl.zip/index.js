"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const child_process_1 = require("child_process");
const sites_1 = require("./sites");
const settings_1 = require("./settings");
function definePlugin(plugin) {
    return plugin;
}
// =========================================
// Helpers
// =========================================
function execAsync(cmd, options) {
    return new Promise((resolve, reject) => {
        (0, child_process_1.exec)(cmd, { maxBuffer: 50 * 1024 * 1024, timeout: options?.timeout }, (error, stdout, stderr) => {
            if (error) {
                reject(Object.assign(error, {
                    stdout: stdout?.toString() ?? "",
                    stderr: stderr?.toString() ?? "",
                }));
            }
            else {
                resolve({
                    stdout: stdout?.toString() ?? "",
                    stderr: stderr?.toString() ?? "",
                });
            }
        });
    });
}
function shellEscape(arg) {
    return `'${arg.replace(/'/g, "'\\''")}'`;
}
/** Escape a string for safe inclusion in XML text content. */
function xmlEscape(s) {
    return s
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&apos;");
}
/**
 * Get a setting value, returning empty string for falsy / "null" / "undefined" values.
 */
function getSetting(settings, key) {
    const raw = settings.get(key);
    if (!raw || raw === "null" || raw === "undefined" || raw === "none")
        return "";
    return raw;
}
/**
 * Get a boolean setting, with a default value.
 */
function getBoolSetting(settings, key, defaultVal) {
    const raw = getSetting(settings, key);
    if (raw === "")
        return defaultVal;
    return raw === "true";
}
/**
 * Resolve the plugin's tracked base folder.
 * `save_directory` is the canonical setting used by the host view registry,
 * while `library_folder` is retained as a legacy fallback.
 */
function getBaseFolder(settings) {
    return getSetting(settings, "save_directory") || getSetting(settings, "library_folder") || "gallery-dl";
}
/**
 * Resolve the output directory for a download URL.
 * Checks the per-site directory overrides first, then falls back to the default library folder.
 */
function resolveOutputDir(url, rootDirectory, baseFolder, settings, logger) {
    const baseOutputDir = path_1.default.join(rootDirectory, baseFolder);
    const raw = getSetting(settings, "site_directories");
    if (!raw)
        return baseOutputDir;
    let siteMap;
    try {
        siteMap = JSON.parse(raw);
    }
    catch {
        logger.warn("site_directories setting is not valid JSON, using default folder");
        return baseOutputDir;
    }
    let hostname;
    try {
        hostname = new URL(url).hostname;
    }
    catch {
        return baseOutputDir;
    }
    for (const [domain, folder] of Object.entries(siteMap)) {
        if (hostname === domain || hostname.endsWith("." + domain)) {
            const segments = folder.split(/[\\/]+/).filter(Boolean);
            if (segments.length === 0) {
                return baseOutputDir;
            }
            const relativePath = segments[0] === baseFolder ? segments : [baseFolder, ...segments];
            logger.info(`Site directory override: ${domain} -> ${relativePath.join("/")}`);
            return path_1.default.join(rootDirectory, ...relativePath);
        }
    }
    return baseOutputDir;
}
// =========================================
// gallery-dl Config Generation
// =========================================
/**
 * Build a gallery-dl configuration object from plugin settings.
 * This is written to a temp config file and passed via --config.
 */
function buildConfig(settings, outputDir, logger) {
    const config = {};
    const extractor = {};
    const downloader = {};
    const postprocessors = [];
    // ── Base directory ──
    extractor["base-directory"] = outputDir;
    // ── Directory / filename templates ──
    const dirTemplate = getSetting(settings, "directory_template");
    if (dirTemplate) {
        extractor["directory"] = dirTemplate.split("/");
    }
    const fnTemplate = getSetting(settings, "filename_template");
    if (fnTemplate) {
        extractor["filename"] = fnTemplate;
    }
    // ── Skip / Archive ──
    const skipExisting = getSetting(settings, "skip_existing") || "true";
    if (skipExisting === "false") {
        extractor["skip"] = false;
    }
    else if (skipExisting === "true") {
        extractor["skip"] = true;
    }
    else {
        extractor["skip"] = skipExisting; // "abort:N", "terminate:N"
    }
    if (getBoolSetting(settings, "download_archive", true)) {
        extractor["archive"] = path_1.default.join(outputDir, ".gallery-dl-archive.sqlite3");
    }
    // ── Filters ──
    const fileFilter = getSetting(settings, "file_filter");
    if (fileFilter)
        extractor["file-filter"] = fileFilter;
    const postFilter = getSetting(settings, "post_filter");
    if (postFilter)
        extractor["post-filter"] = postFilter;
    const fileRange = getSetting(settings, "file_range");
    if (fileRange)
        extractor["file-range"] = fileRange;
    const imageRange = getSetting(settings, "image_range");
    if (imageRange)
        extractor["image-range"] = imageRange;
    // ── Rate limiting ──
    const sleepRequest = getSetting(settings, "sleep_request");
    if (sleepRequest)
        extractor["sleep-request"] = parseFloat(sleepRequest) || sleepRequest;
    const sleepDownload = getSetting(settings, "sleep_download");
    if (sleepDownload)
        extractor["sleep"] = parseFloat(sleepDownload) || sleepDownload;
    const retries = getSetting(settings, "retries");
    if (retries)
        extractor["retries"] = parseInt(retries, 10);
    const timeout = getSetting(settings, "timeout");
    if (timeout)
        extractor["timeout"] = parseFloat(timeout);
    // ── Network ──
    const proxy = getSetting(settings, "proxy");
    if (proxy)
        extractor["proxy"] = proxy;
    const userAgent = getSetting(settings, "user_agent");
    if (userAgent)
        extractor["user-agent"] = userAgent;
    const browser = getSetting(settings, "browser_emulation");
    if (browser)
        extractor["browser"] = browser;
    const verifySsl = getBoolSetting(settings, "verify_ssl", true);
    extractor["verify"] = verifySsl;
    // ── Cookies ──
    const cookiesFile = getSetting(settings, "cookies_file");
    const cookiesBrowser = getSetting(settings, "cookies_from_browser");
    if (cookiesBrowser) {
        // Browser cookie extraction: ["browser", "profile", null, null, ".domain"]
        const profile = getSetting(settings, "cookies_browser_profile") || null;
        const domain = getSetting(settings, "cookies_browser_domain") || null;
        const cookieSpec = [cookiesBrowser];
        if (profile || domain) {
            cookieSpec.push(profile);
            cookieSpec.push(null); // keyring
            cookieSpec.push(null); // container
            if (domain)
                cookieSpec.push(domain);
        }
        extractor["cookies"] = cookieSpec;
    }
    else if (cookiesFile) {
        if (fs_1.default.existsSync(cookiesFile)) {
            extractor["cookies"] = cookiesFile;
        }
        else {
            logger.warn(`Configured cookies file does not exist, skipping: ${cookiesFile}`);
        }
    }
    // ── Downloader ──
    const rateLimit = getSetting(settings, "rate_limit");
    if (rateLimit) {
        downloader["rate"] = rateLimit;
    }
    if (getBoolSetting(settings, "mtime", true)) {
        downloader["mtime"] = true;
    }
    downloader["verify"] = verifySsl;
    // ═══════════════════════════════════════
    // Site-specific authentication & options
    // ═══════════════════════════════════════
    // --- Pixiv ---
    const pixivToken = getSetting(settings, "pixiv_refresh_token");
    if (pixivToken) {
        extractor["pixiv"] = {
            "refresh-token": pixivToken,
            "ugoira": getBoolSetting(settings, "pixiv_ugoira", true),
        };
    }
    // --- DeviantArt ---
    const daToken = getSetting(settings, "deviantart_refresh_token");
    const daClientId = getSetting(settings, "deviantart_client_id");
    const daClientSecret = getSetting(settings, "deviantart_client_secret");
    if (daToken || daClientId) {
        const daCfg = {
            "mature": getBoolSetting(settings, "deviantart_mature", true),
            "original": getBoolSetting(settings, "deviantart_original", true),
        };
        if (daToken)
            daCfg["refresh-token"] = daToken;
        if (daClientId)
            daCfg["client-id"] = daClientId;
        if (daClientSecret)
            daCfg["client-secret"] = daClientSecret;
        extractor["deviantart"] = daCfg;
    }
    // --- Flickr ---
    const flickrToken = getSetting(settings, "flickr_access_token");
    const flickrSecret = getSetting(settings, "flickr_access_token_secret");
    if (flickrToken) {
        extractor["flickr"] = {
            "access-token": flickrToken,
            "access-token-secret": flickrSecret || "",
        };
    }
    // --- Reddit ---
    const redditClientId = getSetting(settings, "reddit_client_id");
    const redditUA = getSetting(settings, "reddit_user_agent") ||
        "TheArchiver/1.0 (reddit content archiver)";
    const redditWhitelist = getSetting(settings, "reddit_whitelist");
    const explicitSleepRequest = getSetting(settings, "sleep_request");
    const redditCfg = {
        "api": "rest",
        "comments": 0,
        "user-agent": redditUA,
    };
    if (redditClientId)
        redditCfg["client-id"] = redditClientId;
    if (redditWhitelist) {
        redditCfg["whitelist"] = redditWhitelist.split(",").map((s) => s.trim());
    }
    if (!explicitSleepRequest) {
        // Mirror Plugin-Social's conservative Reddit pacing (~9.2 req/min)
        // to reduce the chance of Reddit returning its block page.
        redditCfg["sleep-request"] = 6.5;
    }
    extractor["reddit"] = redditCfg;
    // --- Tumblr ---
    const tumblrToken = getSetting(settings, "tumblr_access_token");
    const tumblrSecret = getSetting(settings, "tumblr_access_token_secret");
    if (tumblrToken) {
        extractor["tumblr"] = {
            "access-token": tumblrToken,
            "access-token-secret": tumblrSecret || "",
        };
    }
    // --- SmugMug ---
    const smugToken = getSetting(settings, "smugmug_access_token");
    const smugSecret = getSetting(settings, "smugmug_access_token_secret");
    if (smugToken) {
        extractor["smugmug"] = {
            "access-token": smugToken,
            "access-token-secret": smugSecret || "",
        };
    }
    // --- Mastodon ---
    const mastodonInstance = getSetting(settings, "mastodon_instance");
    const mastodonToken = getSetting(settings, "mastodon_access_token");
    if (mastodonInstance && mastodonToken) {
        extractor["mastodon"] = {
            [mastodonInstance]: {
                "root": `https://${mastodonInstance}`,
                "access-token": mastodonToken,
            },
        };
    }
    // --- Bluesky ---
    const bskyUser = getSetting(settings, "bluesky_username");
    const bskyPass = getSetting(settings, "bluesky_password");
    if (bskyUser && bskyPass) {
        extractor["bluesky"] = {
            "username": bskyUser,
            "password": bskyPass,
        };
    }
    // --- Sankaku ---
    const sankakuUser = getSetting(settings, "sankaku_username");
    const sankakuPass = getSetting(settings, "sankaku_password");
    if (sankakuUser && sankakuPass) {
        extractor["sankaku"] = {
            "username": sankakuUser,
            "password": sankakuPass,
        };
    }
    // --- Nijie ---
    const nijieUser = getSetting(settings, "nijie_username");
    const nijiePass = getSetting(settings, "nijie_password");
    if (nijieUser && nijiePass) {
        extractor["nijie"] = {
            "username": nijieUser,
            "password": nijiePass,
        };
    }
    // --- Inkbunny ---
    const inkbunnyUser = getSetting(settings, "inkbunny_username");
    const inkbunnyPass = getSetting(settings, "inkbunny_password");
    if (inkbunnyUser && inkbunnyPass) {
        extractor["inkbunny"] = {
            "username": inkbunnyUser,
            "password": inkbunnyPass,
        };
    }
    // --- MangaDex ---
    const mangadexUser = getSetting(settings, "mangadex_username");
    const mangadexPass = getSetting(settings, "mangadex_password");
    if (mangadexUser && mangadexPass) {
        extractor["mangadex"] = {
            "username": mangadexUser,
            "password": mangadexPass,
        };
    }
    // --- SubscribeStar ---
    const ssUser = getSetting(settings, "subscribestar_username");
    const ssPass = getSetting(settings, "subscribestar_password");
    if (ssUser && ssPass) {
        extractor["subscribestar"] = {
            "username": ssUser,
            "password": ssPass,
        };
    }
    // --- Newgrounds ---
    const ngUser = getSetting(settings, "newgrounds_username");
    const ngPass = getSetting(settings, "newgrounds_password");
    if (ngUser && ngPass) {
        extractor["newgrounds"] = {
            "username": ngUser,
            "password": ngPass,
        };
    }
    // --- Zerochan ---
    const zcUser = getSetting(settings, "zerochan_username");
    const zcPass = getSetting(settings, "zerochan_password");
    if (zcUser && zcPass) {
        extractor["zerochan"] = {
            "username": zcUser,
            "password": zcPass,
        };
    }
    // --- Aryion ---
    const aryionUser = getSetting(settings, "aryion_username");
    const aryionPass = getSetting(settings, "aryion_password");
    if (aryionUser && aryionPass) {
        extractor["aryion"] = {
            "username": aryionUser,
            "password": aryionPass,
        };
    }
    // --- Tapas ---
    const tapasUser = getSetting(settings, "tapas_username");
    const tapasPass = getSetting(settings, "tapas_password");
    if (tapasUser && tapasPass) {
        extractor["tapas"] = {
            "username": tapasUser,
            "password": tapasPass,
        };
    }
    // --- Danbooru ---
    const danbooruUser = getSetting(settings, "danbooru_username");
    const danbooruKey = getSetting(settings, "danbooru_api_key");
    if (danbooruUser && danbooruKey) {
        extractor["danbooru"] = {
            "username": danbooruUser,
            "password": danbooruKey,
        };
    }
    // --- e621 ---
    const e621User = getSetting(settings, "e621_username");
    const e621Key = getSetting(settings, "e621_api_key");
    if (e621User && e621Key) {
        extractor["e621"] = {
            "username": e621User,
            "password": e621Key,
        };
    }
    // --- Gelbooru ---
    const gelbooruKey = getSetting(settings, "gelbooru_api_key");
    const gelbooruUserId = getSetting(settings, "gelbooru_user_id");
    if (gelbooruKey) {
        extractor["gelbooru"] = {
            "api-key": gelbooruKey,
            "user-id": gelbooruUserId || "",
        };
    }
    // --- Civitai ---
    const civitaiKey = getSetting(settings, "civitai_api_key");
    if (civitaiKey) {
        extractor["civitai"] = { "api-key": civitaiKey };
    }
    // --- Wallhaven ---
    const wallhavenKey = getSetting(settings, "wallhaven_api_key");
    if (wallhavenKey) {
        extractor["wallhaven"] = { "api-key": wallhavenKey };
    }
    // --- Weasyl ---
    const weasylKey = getSetting(settings, "weasyl_api_key");
    if (weasylKey) {
        extractor["weasyl"] = { "api-key": weasylKey };
    }
    // --- Imgur ---
    const imgurClientId = getSetting(settings, "imgur_client_id");
    if (imgurClientId) {
        extractor["imgur"] = { "client-id": imgurClientId };
    }
    // --- Discord ---
    const discordToken = getSetting(settings, "discord_token");
    if (discordToken) {
        extractor["discord"] = { "token": discordToken };
    }
    // --- Fansly ---
    const fanslyToken = getSetting(settings, "fansly_token");
    if (fanslyToken) {
        extractor["fansly"] = { "token": fanslyToken };
    }
    // --- Gofile ---
    const gofileToken = getSetting(settings, "gofile_api_token");
    if (gofileToken) {
        extractor["gofile"] = { "api-token": gofileToken };
    }
    // --- ImageChest ---
    const imgchestToken = getSetting(settings, "imagechest_access_token");
    if (imgchestToken) {
        extractor["imagechest"] = { "access-token": imgchestToken };
    }
    // --- Twitter-specific ---
    const twitterCfg = {};
    if (!getBoolSetting(settings, "twitter_text_tweets", false)) {
        twitterCfg["text-tweets"] = false;
    }
    else {
        twitterCfg["text-tweets"] = true;
    }
    twitterCfg["retweets"] = getBoolSetting(settings, "twitter_retweets", false);
    twitterCfg["quoted"] = getBoolSetting(settings, "twitter_quoted", false);
    if (Object.keys(twitterCfg).length > 0) {
        extractor["twitter"] = twitterCfg;
    }
    // --- Instagram-specific ---
    const igInclude = getSetting(settings, "instagram_include");
    if (igInclude) {
        extractor["instagram"] = {
            "include": igInclude,
        };
    }
    // --- ExHentai-specific ---
    const exSleep = getSetting(settings, "exhentai_sleep");
    if (exSleep) {
        const exCfg = {};
        if (exSleep.includes("-")) {
            exCfg["sleep-request"] = exSleep;
        }
        else {
            exCfg["sleep-request"] = parseFloat(exSleep) || 3.0;
        }
        extractor["exhentai"] = exCfg;
    }
    // --- Kemono-specific ---
    const kemonoFavs = getBoolSetting(settings, "kemono_favorites", false);
    const kemonoComments = getBoolSetting(settings, "kemono_comments", false);
    if (kemonoFavs || kemonoComments) {
        extractor["kemono"] = {
            "favorites": kemonoFavs,
            "comments": kemonoComments,
        };
    }
    // ═══════════════════════════════════════
    // Post-processors
    // ═══════════════════════════════════════
    // Metadata JSON
    if (getBoolSetting(settings, "write_metadata", true)) {
        postprocessors.push({
            "name": "metadata",
            "mode": "json",
            "event": "post",
        });
    }
    // Tag files
    if (getBoolSetting(settings, "write_tags", false)) {
        postprocessors.push({
            "name": "metadata",
            "mode": "tags",
            "event": "post",
        });
    }
    // CBZ manga archiving
    if (getBoolSetting(settings, "zip_manga", false)) {
        postprocessors.push({
            "name": "zip",
            "compression": "stored",
            "extension": "cbz",
        });
    }
    // Ugoira conversion
    const ugoiraFormat = getSetting(settings, "ugoira_convert");
    if (ugoiraFormat) {
        const ugoiraPP = {
            "name": "ugoira",
            "extension": ugoiraFormat,
            "ffmpeg-twopass": ugoiraFormat === "webm",
            "libx264-prevent-odd": ugoiraFormat === "mp4",
        };
        if (ugoiraFormat === "gif") {
            ugoiraPP["ffmpeg-args"] = [
                "-filter_complex", "[0:v] split [a][b];[a] palettegen=stats_mode=single [p];[b][p] paletteuse=dither=bayer:bayer_scale=5:new=1",
            ];
        }
        postprocessors.push(ugoiraPP);
    }
    // Exec after download
    const execAfter = getSetting(settings, "exec_after");
    if (execAfter) {
        postprocessors.push({
            "name": "exec",
            "command": execAfter,
            "event": "after",
        });
    }
    // Assign postprocessors
    if (postprocessors.length > 0) {
        extractor["postprocessors"] = postprocessors;
    }
    // ── Assemble config ──
    config["extractor"] = extractor;
    if (Object.keys(downloader).length > 0) {
        config["downloader"] = downloader;
    }
    // Output logging
    if (getBoolSetting(settings, "verbose", false)) {
        config["output"] = {
            "log": { "level": "debug" },
        };
    }
    return config;
}
/**
 * Merge a user-provided custom config (JSON) with the generated config.
 * Generated config keys take precedence.
 */
function mergeConfigs(generated, custom) {
    const merged = { ...custom };
    for (const [key, value] of Object.entries(generated)) {
        if (typeof value === "object" &&
            value !== null &&
            !Array.isArray(value) &&
            typeof merged[key] === "object" &&
            merged[key] !== null &&
            !Array.isArray(merged[key])) {
            merged[key] = mergeConfigs(value, merged[key]);
        }
        else {
            merged[key] = value;
        }
    }
    return merged;
}
function sanitizeGalleryDlErrorOutput(raw) {
    if (!raw)
        return raw;
    const lines = raw
        .split("\n")
        .map((line) => line.trim())
        .filter(Boolean)
        .filter((line) => !line.includes("InsecureRequestWarning"))
        .filter((line) => !line.includes("urllib3/connectionpool.py"))
        .filter((line) => !line.includes("warnings.warn("));
    const cleaned = lines.join("\n");
    if (cleaned.includes("You've been blocked by network security")) {
        return "Reddit blocked the request with its network security page. This is usually an IP/account/access-policy issue, not a macOS-specific TLS problem.";
    }
    return cleaned;
}
// =========================================
// Direct Reddit Downloader
// =========================================
const REDDIT_USER_AGENT = "TheArchiver/1.0 (reddit content archiver)";
const REDDIT_MIN_REQUEST_INTERVAL_MS = 6500;
const REDDIT_DEFAULT_LISTING_COUNT = 100;
let lastRedditRequestTime = 0;
function parseRedditUrl(url) {
    let parsed;
    try {
        parsed = new URL(url);
    }
    catch {
        return null;
    }
    const hostname = parsed.hostname.replace(/^(www\.|old\.)/, "");
    if (hostname === "redd.it") {
        const postId = parsed.pathname.split("/").filter(Boolean)[0];
        return postId ? { type: "post", postId } : null;
    }
    if (hostname !== "reddit.com") {
        return null;
    }
    const segments = parsed.pathname.split("/").filter(Boolean);
    if (segments.length === 0)
        return null;
    if (segments.length >= 4 && segments[0] === "r" && segments[2] === "comments") {
        return { type: "post", subreddit: segments[1], postId: segments[3] };
    }
    if (segments.length >= 2 && (segments[0] === "comments" || segments[0] === "gallery")) {
        return { type: "post", postId: segments[1] };
    }
    if (segments.length >= 2 && (segments[0] === "u" || segments[0] === "user")) {
        return { type: "user", username: segments[1] };
    }
    if (segments.length >= 2 && segments[0] === "r") {
        return { type: "subreddit", subreddit: segments[1] };
    }
    return null;
}
async function fetchRedditJson(url, logger) {
    const parsedUrl = new URL(url);
    parsedUrl.searchParams.set("raw_json", "1");
    const fetchUrl = parsedUrl.toString();
    logger.info(`Fetching Reddit JSON: ${fetchUrl}`);
    const res = await fetch(fetchUrl, {
        headers: {
            "User-Agent": REDDIT_USER_AGENT,
            "Accept": "application/json",
        },
        redirect: "follow",
    });
    if (res.status === 429) {
        logger.warn("Rate limited by Reddit. Waiting 60 seconds before retry...");
        await new Promise((resolve) => setTimeout(resolve, 60000));
        return fetchRedditJson(url, logger);
    }
    if (!res.ok) {
        const text = await res.text().catch(() => "");
        if (text.includes("You've been blocked by network security")) {
            throw new Error("Reddit blocked the request with its network security page. This public JSON route is currently blocked from this environment.");
        }
        throw new Error(`Reddit API returned ${res.status}: ${res.statusText}`);
    }
    return res.json();
}
async function rateLimitedRedditFetch(url, logger) {
    const now = Date.now();
    const elapsed = now - lastRedditRequestTime;
    if (elapsed < REDDIT_MIN_REQUEST_INTERVAL_MS) {
        const waitTime = REDDIT_MIN_REQUEST_INTERVAL_MS - elapsed;
        logger.info(`Rate limiting Reddit requests: waiting ${waitTime}ms`);
        await new Promise((resolve) => setTimeout(resolve, waitTime));
    }
    lastRedditRequestTime = Date.now();
    return fetchRedditJson(url, logger);
}
async function fetchAllRedditPosts(baseJsonUrl, maxPosts, logger) {
    const effectiveMax = maxPosts === -1 ? 1000 : Math.min(maxPosts, 1000);
    const results = [];
    let after = null;
    while (results.length < effectiveMax) {
        const url = new URL(baseJsonUrl);
        url.searchParams.set("limit", "100");
        if (after)
            url.searchParams.set("after", after);
        const response = (await rateLimitedRedditFetch(url.toString(), logger));
        if (!response?.data?.children?.length)
            break;
        const posts = response.data.children
            .filter((child) => child.kind === "t3")
            .map((child) => child.data);
        if (posts.length === 0)
            break;
        results.push(...posts);
        after = response.data.after;
        if (!after)
            break;
    }
    return results.slice(0, effectiveMax);
}
function getMimeExtension(mime) {
    const map = {
        "image/jpg": "jpg",
        "image/jpeg": "jpg",
        "image/png": "png",
        "image/gif": "gif",
        "image/webp": "webp",
        "image/avif": "avif",
    };
    return map[mime.toLowerCase()] || "jpg";
}
function truncateTitle(title, maxLen = 100) {
    if (title.length <= maxLen)
        return title;
    return title.substring(0, maxLen).replace(/[-_\s]+$/, "");
}
function decodeHtmlEntities(str) {
    return str
        .replace(/&amp;/g, "&")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&quot;/g, "\"")
        .replace(/&#039;/g, "'")
        .replace(/&#x27;/g, "'");
}
function filenameFromUrl(url) {
    try {
        const pathname = new URL(url).pathname;
        const base = path_1.default.basename(pathname);
        return base && path_1.default.extname(base) ? base : null;
    }
    catch {
        return null;
    }
}
function isVideoRedditPost(post) {
    return (post.is_video === true ||
        post.post_hint === "hosted:video" ||
        post.post_hint === "rich:video" ||
        (post.domain === "v.redd.it" && !post.is_gallery));
}
function extractRedditMediaItems(post, sanitizeFilename) {
    const sourcePost = post.crosspost_parent_list && post.crosspost_parent_list.length > 0
        ? post.crosspost_parent_list[0]
        : post;
    if (isVideoRedditPost(sourcePost))
        return [];
    const items = [];
    if (sourcePost.is_gallery && sourcePost.media_metadata) {
        const galleryItems = sourcePost.gallery_data?.items;
        const orderedIds = galleryItems
            ? galleryItems.map((item) => item.media_id)
            : Object.keys(sourcePost.media_metadata);
        const captionMap = new Map();
        if (galleryItems) {
            for (const item of galleryItems) {
                if (item.caption)
                    captionMap.set(item.media_id, item.caption);
            }
        }
        let index = 0;
        for (const mediaId of orderedIds) {
            const meta = sourcePost.media_metadata[mediaId];
            if (!meta || meta.status !== "valid")
                continue;
            let imageUrl;
            if (meta.e === "AnimatedImage" && meta.s?.gif)
                imageUrl = meta.s.gif;
            else if (meta.s?.u)
                imageUrl = meta.s.u;
            if (!imageUrl)
                continue;
            imageUrl = decodeHtmlEntities(imageUrl);
            index++;
            const ext = getMimeExtension(meta.m);
            const caption = captionMap.get(mediaId);
            const filename = caption
                ? `${sanitizeFilename(truncateTitle(caption, 80))}.${ext}`
                : `Image ${index}.${ext}`;
            items.push({ url: imageUrl, filename });
        }
        return items;
    }
    if (sourcePost.post_hint === "image" ||
        sourcePost.domain === "i.redd.it" ||
        sourcePost.domain === "i.imgur.com") {
        const originalName = filenameFromUrl(sourcePost.url);
        items.push({ url: sourcePost.url, filename: originalName || "Image 1.jpg" });
        return items;
    }
    if (sourcePost.preview?.images?.[0]?.source?.url) {
        const previewUrl = decodeHtmlEntities(sourcePost.preview.images[0].source.url);
        try {
            const previewHost = new URL(previewUrl).hostname;
            if (previewHost === "i.redd.it" || previewHost === "preview.redd.it") {
                items.push({
                    url: previewUrl,
                    filename: filenameFromUrl(previewUrl) || "Image 1.jpg",
                });
                return items;
            }
        }
        catch {
            // ignore invalid preview URL
        }
    }
    return items;
}
function writeRedditCommentsFromListing(commentsData, postDir, logger) {
    const listing = commentsData;
    if (!Array.isArray(listing?.data?.children))
        return;
    const commentsPath = path_1.default.join(postDir, "Comments.json");
    const comments = processRedditComments(listing.data.children);
    try {
        fs_1.default.writeFileSync(commentsPath, JSON.stringify(comments, null, 2), "utf8");
        logger.info(`Wrote ${comments.length} Reddit comments: ${commentsPath}`);
    }
    catch (err) {
        logger.warn(`Failed to write Reddit comments: ${err}`);
    }
}
function buildRedditCommentsUrl(post) {
    if (post.permalink) {
        const permalink = post.permalink.startsWith("http")
            ? post.permalink
            : `https://www.reddit.com${post.permalink}`;
        return permalink.replace(/\/+$/, "") + ".json";
    }
    if (post.subreddit) {
        return `https://www.reddit.com/r/${post.subreddit}/comments/${post.id}.json`;
    }
    return `https://www.reddit.com/comments/${post.id}.json`;
}
function redditPostFolderName(post, sanitizeFilename) {
    return sanitizeFilename(truncateTitle(post.title, 100)) || post.id;
}
async function downloadRedditPostToFolder(context, post, postDir, sourceUrl, fetchComments) {
    const { helpers, logger } = context;
    await helpers.io.ensureDir(postDir);
    writeRedditPostNfo(post, sourceUrl, postDir, logger);
    if (fetchComments) {
        try {
            const commentUrl = buildRedditCommentsUrl(post);
            const response = (await rateLimitedRedditFetch(commentUrl, logger));
            if (Array.isArray(response) && response.length >= 2) {
                writeRedditCommentsFromListing(response[1], postDir, logger);
            }
            else {
                writeRedditCommentsFromListing({ data: { children: [] } }, postDir, logger);
            }
        }
        catch (err) {
            logger.warn(`Failed to fetch comments for post ${post.id}: ${err}`);
            writeRedditCommentsFromListing({ data: { children: [] } }, postDir, logger);
        }
    }
    if (isVideoRedditPost(post)) {
        return { downloaded: 0, skipped: 0, isVideo: true };
    }
    const mediaItems = extractRedditMediaItems(post, helpers.string.sanitizeFilename);
    if (mediaItems.length === 0) {
        return { downloaded: 0, skipped: 0, isVideo: false };
    }
    const downloads = [];
    let skipped = 0;
    for (const item of mediaItems) {
        const outputPath = path_1.default.join(postDir, item.filename);
        if (await helpers.io.fileExists(outputPath))
            skipped++;
        else
            downloads.push({ url: item.url, outputPath });
    }
    if (downloads.length > 0) {
        await helpers.io.downloadFiles(downloads, context.maxDownloadThreads);
    }
    return { downloaded: downloads.length, skipped, isVideo: false };
}
async function handleDirectRedditDownload(context) {
    const parsed = parseRedditUrl(context.url);
    if (!parsed) {
        return { success: false, message: "Could not parse Reddit URL" };
    }
    const { url, rootDirectory, settings, logger, helpers } = context;
    const baseFolder = getBaseFolder(settings);
    const siteRoot = resolveOutputDir(url, rootDirectory, baseFolder, settings, logger);
    const fetchComments = getBoolSetting(settings, "write_metadata", true);
    if (parsed.type === "post") {
        const jsonUrl = parsed.subreddit
            ? `https://www.reddit.com/r/${parsed.subreddit}/comments/${parsed.postId}.json`
            : `https://www.reddit.com/comments/${parsed.postId}.json`;
        const response = (await rateLimitedRedditFetch(jsonUrl, logger));
        if (!Array.isArray(response) || response.length < 1) {
            return { success: false, message: "Unexpected response from Reddit" };
        }
        const postListing = response[0];
        const post = postListing?.data?.children?.[0]?.data;
        if (!post)
            return { success: false, message: "Could not find Reddit post data" };
        const postDir = path_1.default.join(siteRoot, post.subreddit, redditPostFolderName(post, helpers.string.sanitizeFilename));
        const result = await downloadRedditPostToFolder(context, post, postDir, url, fetchComments);
        if (result.isVideo) {
            return {
                success: true,
                message: `Archived Reddit video post metadata to ${postDir}`,
            };
        }
        return {
            success: true,
            message: `Archived Reddit post to ${postDir}`,
        };
    }
    if (parsed.type === "user") {
        const posts = await fetchAllRedditPosts(`https://www.reddit.com/user/${parsed.username}/submitted.json`, REDDIT_DEFAULT_LISTING_COUNT, logger);
        if (posts.length === 0) {
            return { success: false, message: `No posts found for u/${parsed.username}` };
        }
        let totalDownloaded = 0;
        for (const post of posts) {
            const postDir = path_1.default.join(siteRoot, parsed.username, post.subreddit, redditPostFolderName(post, helpers.string.sanitizeFilename));
            const result = await downloadRedditPostToFolder(context, post, postDir, url, fetchComments);
            totalDownloaded += result.downloaded;
        }
        return {
            success: true,
            message: `Archived ${posts.length} Reddit posts from u/${parsed.username} (${totalDownloaded} media files)`,
        };
    }
    const posts = await fetchAllRedditPosts(`https://www.reddit.com/r/${parsed.subreddit}/hot.json`, REDDIT_DEFAULT_LISTING_COUNT, logger);
    if (posts.length === 0) {
        return { success: false, message: `No posts found in r/${parsed.subreddit}` };
    }
    let totalDownloaded = 0;
    for (const post of posts) {
        const postDir = path_1.default.join(siteRoot, parsed.subreddit, redditPostFolderName(post, helpers.string.sanitizeFilename));
        const result = await downloadRedditPostToFolder(context, post, postDir, url, fetchComments);
        totalDownloaded += result.downloaded;
    }
    return {
        success: true,
        message: `Archived ${posts.length} Reddit posts from r/${parsed.subreddit} (${totalDownloaded} media files)`,
    };
}
// =========================================
// Social Media Post-Processing
// =========================================
/** Detect which social platform a URL belongs to */
function detectSocialPlatform(url) {
    try {
        const hostname = new URL(url).hostname.toLowerCase();
        if (hostname.includes("reddit.com") || hostname.includes("redd.it"))
            return "reddit";
        if (hostname.includes("bsky.app") || hostname.includes("bsky.social"))
            return "bluesky";
        if (hostname.includes("twitter.com") || hostname.includes("x.com") || hostname.includes("nitter"))
            return "twitter";
        return null;
    }
    catch {
        return null;
    }
}
/**
 * After gallery-dl downloads social media content, scan for its JSON metadata
 * and generate Post.nfo + Comments/Replies files for the viewer.
 */
async function enrichSocialMetadata(outputDir, sourceUrl, platform, logger) {
    logger.info(`Enriching ${platform} metadata for viewer compatibility...`);
    // Find gallery-dl JSON metadata files
    const metaFiles = await findJsonMetadata(outputDir);
    for (const metaFile of metaFiles) {
        try {
            const raw = fs_1.default.readFileSync(metaFile, "utf8");
            const meta = JSON.parse(raw);
            const dir = path_1.default.dirname(metaFile);
            const nfoPath = path_1.default.join(dir, "Post.nfo");
            // Skip if Post.nfo already exists
            if (fs_1.default.existsSync(nfoPath))
                continue;
            switch (platform) {
                case "reddit":
                    writeRedditPostNfo(meta, sourceUrl, dir, logger);
                    await fetchRedditComments(meta, dir, logger);
                    break;
                case "bluesky":
                    writeBlueskyPostNfo(meta, sourceUrl, dir, logger);
                    await fetchBlueskyReplies(meta, dir, logger);
                    break;
                case "twitter":
                    writeTwitterPostNfo(meta, sourceUrl, dir, logger);
                    break;
            }
        }
        catch (err) {
            logger.warn(`Failed to enrich metadata from ${metaFile}: ${err}`);
        }
    }
}
// ── Reddit NFO Generation ──
function writeRedditPostNfo(meta, sourceUrl, dir, logger) {
    const nfoPath = path_1.default.join(dir, "Post.nfo");
    const lines = [
        `<?xml version="1.0" encoding="UTF-8"?>`,
        `<postdetails>`,
    ];
    const add = (tag, value) => {
        if (value !== undefined && value !== null && value !== "") {
            lines.push(`  <${tag}>${xmlEscape(String(value))}</${tag}>`);
        }
    };
    // gallery-dl reddit metadata fields
    add("id", meta.id);
    add("fullname", meta.fullname || (meta.id ? `t3_${meta.id}` : ""));
    add("author", meta.author || meta.user || "[deleted]");
    add("subreddit", meta.subreddit);
    add("subreddit_prefixed", meta.subreddit ? `r/${meta.subreddit}` : "");
    add("title", meta.title || meta.description);
    add("url", meta.permalink ? `https://www.reddit.com${meta.permalink}` : sourceUrl);
    add("source_url", sourceUrl);
    add("score", meta.score);
    add("upvote_ratio", meta.upvote_ratio);
    add("num_comments", meta.num_comments);
    add("created", meta.date || (meta.created_utc ? new Date(meta.created_utc * 1000).toISOString() : ""));
    add("over_18", meta.over_18);
    add("spoiler", meta.spoiler);
    add("stickied", meta.stickied);
    add("locked", meta.locked);
    add("is_video", meta.is_video);
    add("is_gallery", meta.is_gallery);
    add("post_hint", meta.post_hint);
    add("flair", meta.link_flair_text || meta.flair);
    add("selftext", meta.selftext);
    add("domain", meta.domain);
    add("media_url", meta.url);
    lines.push(`</postdetails>`);
    try {
        fs_1.default.writeFileSync(nfoPath, lines.join("\n") + "\n", "utf8");
        logger.info(`Wrote Reddit Post.nfo: ${nfoPath}`);
    }
    catch (err) {
        logger.warn(`Failed to write Reddit Post.nfo: ${err}`);
    }
}
async function fetchRedditComments(meta, dir, logger) {
    const commentsPath = path_1.default.join(dir, "Comments.json");
    if (fs_1.default.existsSync(commentsPath))
        return;
    const postId = meta.id;
    if (!postId)
        return;
    try {
        const permalink = meta.permalink;
        const subreddit = meta.subreddit;
        const normalizedPermalink = permalink
            ? String(permalink).startsWith("http")
                ? String(permalink)
                : `https://www.reddit.com${String(permalink)}`
            : undefined;
        const url = permalink
            ? `${normalizedPermalink.replace(/\/+$/, "")}.json`
            : subreddit
                ? `https://www.reddit.com/r/${subreddit}/comments/${postId}.json`
                : `https://www.reddit.com/comments/${postId}.json`;
        logger.info(`Fetching Reddit comments: ${url}`);
        const data = await fetchRedditJson(url, logger);
        if (!Array.isArray(data) || data.length < 2)
            return;
        const commentListing = data[1];
        const children = commentListing?.data?.children;
        if (!Array.isArray(children)) {
            fs_1.default.writeFileSync(commentsPath, JSON.stringify([], null, 2), "utf8");
            return;
        }
        const comments = processRedditComments(children);
        fs_1.default.writeFileSync(commentsPath, JSON.stringify(comments, null, 2), "utf8");
        logger.info(`Saved ${comments.length} Reddit comments to: ${commentsPath}`);
    }
    catch (err) {
        logger.warn(`Failed to fetch Reddit comments: ${err}`);
        try {
            fs_1.default.writeFileSync(commentsPath, JSON.stringify([], null, 2), "utf8");
        }
        catch {
            // ignore secondary write failure
        }
    }
}
function processRedditComments(children) {
    const result = [];
    for (const child of children) {
        const c = child;
        if (c.kind === "more") {
            result.push({
                kind: "more",
                count: c.data.count || 0,
                children_ids: c.data.children || [],
            });
            continue;
        }
        if (c.kind !== "t1")
            continue;
        const d = c.data;
        const comment = {
            author: d.author || "[deleted]",
            body: d.body || "",
            score: d.score || 0,
            created_utc: d.created_utc || 0,
            edited: d.edited || false,
            is_submitter: d.is_submitter || false,
            stickied: d.stickied || false,
            distinguished: d.distinguished || null,
            author_flair_text: d.author_flair_text || null,
            depth: d.depth || 0,
            replies: [],
        };
        // Process nested replies
        if (d.replies && typeof d.replies === "object") {
            const replyData = d.replies;
            if (replyData.data?.children) {
                comment.replies = processRedditComments(replyData.data.children);
            }
        }
        result.push(comment);
    }
    return result;
}
// ── Bluesky NFO Generation ──
function writeBlueskyPostNfo(meta, sourceUrl, dir, logger) {
    const nfoPath = path_1.default.join(dir, "Post.nfo");
    const lines = [
        `<?xml version="1.0" encoding="UTF-8"?>`,
        `<blueskypost>`,
    ];
    const add = (tag, value) => {
        if (value !== undefined && value !== null && value !== "") {
            lines.push(`  <${tag}>${xmlEscape(String(value))}</${tag}>`);
        }
    };
    // gallery-dl bluesky metadata fields
    const record = (meta.record || meta);
    const author = (meta.author || {});
    add("uri", meta.uri);
    add("cid", meta.cid);
    add("text", record.text || meta.text || meta.description);
    add("handle", author.handle || meta.user || meta.handle);
    add("did", author.did || meta.did);
    add("display_name", author.displayName || author.display_name || meta.display_name);
    add("avatar_url", author.avatar || meta.avatar);
    add("url", sourceUrl);
    add("source_url", sourceUrl);
    add("created", record.createdAt || meta.date || meta.created_at);
    // Engagement
    add("like_count", meta.likeCount ?? meta.like_count ?? 0);
    add("reply_count", meta.replyCount ?? meta.reply_count ?? 0);
    add("repost_count", meta.repostCount ?? meta.repost_count ?? 0);
    add("quote_count", meta.quoteCount ?? meta.quote_count ?? 0);
    // Facets (rich text annotations)
    const facets = (record.facets || meta.facets);
    if (facets && facets.length > 0) {
        lines.push("  <facets>");
        for (const facet of facets) {
            const index = facet.index;
            const features = facet.features;
            if (!index || !features)
                continue;
            for (const feature of features) {
                const $type = feature.$type;
                let type = "link";
                const attrs = [];
                if ($type?.includes("link")) {
                    type = "link";
                    attrs.push(`uri="${xmlEscape(String(feature.uri || ""))}"`);
                }
                else if ($type?.includes("mention")) {
                    type = "mention";
                    attrs.push(`did="${xmlEscape(String(feature.did || ""))}"`);
                }
                else if ($type?.includes("tag")) {
                    type = "tag";
                    attrs.push(`tag="${xmlEscape(String(feature.tag || ""))}"`);
                }
                lines.push(`    <facet type="${type}" byte_start="${index.byteStart || 0}" byte_end="${index.byteEnd || 0}" ${attrs.join(" ")} />`);
            }
        }
        lines.push("  </facets>");
    }
    // Embed: external link
    const embed = (record.embed || meta.embed);
    if (embed) {
        const external = (embed.external || embed);
        if (external?.uri) {
            lines.push("  <external_link>");
            add("link_uri", external.uri);
            add("link_title", external.title);
            add("link_description", external.description);
            add("link_thumb", external.thumb?.ref || external.thumb);
            lines.push("  </external_link>");
        }
    }
    // Image count
    if (meta.image_count || meta.imageCount) {
        add("image_count", meta.image_count || meta.imageCount);
    }
    lines.push(`</blueskypost>`);
    try {
        fs_1.default.writeFileSync(nfoPath, lines.join("\n") + "\n", "utf8");
        logger.info(`Wrote Bluesky Post.nfo: ${nfoPath}`);
    }
    catch (err) {
        logger.warn(`Failed to write Bluesky Post.nfo: ${err}`);
    }
}
async function fetchBlueskyReplies(meta, dir, logger) {
    const repliesPath = path_1.default.join(dir, "Replies.json");
    if (fs_1.default.existsSync(repliesPath))
        return;
    // Extract post URI parts
    const uri = meta.uri;
    if (!uri)
        return;
    // URI format: at://did:plc:xxx/app.bsky.feed.post/rkey
    const uriParts = uri.split("/");
    const rkey = uriParts[uriParts.length - 1];
    const did = uriParts[2];
    if (!rkey || !did)
        return;
    try {
        const apiUrl = `https://public.api.bsky.app/xrpc/app.bsky.feed.getPostThread?uri=${encodeURIComponent(uri)}&depth=10`;
        logger.info(`Fetching Bluesky replies...`);
        const res = await fetch(apiUrl, {
            headers: { "Accept": "application/json" },
        });
        if (!res.ok) {
            logger.warn(`Failed to fetch Bluesky replies: ${res.status}`);
            return;
        }
        const data = await res.json();
        if (!data.thread?.replies?.length)
            return;
        const replies = processBlueskyReplies(data.thread.replies);
        fs_1.default.writeFileSync(repliesPath, JSON.stringify(replies, null, 2), "utf8");
        logger.info(`Saved ${replies.length} Bluesky replies to: ${repliesPath}`);
    }
    catch (err) {
        logger.warn(`Failed to fetch Bluesky replies: ${err}`);
    }
}
function processBlueskyReplies(replies) {
    const result = [];
    for (const reply of replies) {
        const r = reply;
        if (!r.post)
            continue;
        const p = r.post;
        const entry = {
            author: p.author?.handle || "unknown",
            displayName: p.author?.displayName,
            avatarUrl: p.author?.avatar,
            text: p.record?.text || "",
            createdAt: p.record?.createdAt || "",
            likeCount: p.likeCount || 0,
            repostCount: p.repostCount || 0,
            replyCount: p.replyCount || 0,
            facets: p.record?.facets,
            depth: 0,
            replies: r.replies ? processBlueskyReplies(r.replies) : [],
        };
        result.push(entry);
    }
    return result;
}
// ── Twitter NFO Generation ──
function writeTwitterPostNfo(meta, sourceUrl, dir, logger) {
    const nfoPath = path_1.default.join(dir, "Post.nfo");
    const lines = [
        `<?xml version="1.0" encoding="UTF-8"?>`,
        `<twitterpost>`,
    ];
    const add = (tag, value) => {
        if (value !== undefined && value !== null && value !== "") {
            lines.push(`  <${tag}>${xmlEscape(String(value))}</${tag}>`);
        }
    };
    // gallery-dl twitter metadata
    const user = (meta.user || meta.author || {});
    add("id", meta.tweet_id || meta.id);
    add("screen_name", user.screen_name || user.name || meta.user || meta.author);
    add("name", user.name || user.screen_name || meta.user);
    add("user_id", user.id || user.id_str);
    add("text", meta.content || meta.text || meta.description);
    add("url", sourceUrl);
    add("source_url", sourceUrl);
    add("profile_image_url", user.profile_image_url_https || user.profile_image_url || meta.avatar);
    add("verified", user.verified);
    add("created", meta.date || meta.created_at);
    add("favorite_count", meta.favorite_count ?? meta.like_count ?? 0);
    add("retweet_count", meta.retweet_count ?? 0);
    add("reply_count", meta.reply_count ?? 0);
    add("quote_count", meta.quote_count ?? 0);
    add("lang", meta.lang);
    // Reply info
    if (meta.in_reply_to_status_id || meta.in_reply_to_screen_name) {
        lines.push("  <reply>");
        add("in_reply_to_id", meta.in_reply_to_status_id);
        add("in_reply_to_user", meta.in_reply_to_screen_name);
        lines.push("  </reply>");
    }
    // Entities: hashtags
    const entities = (meta.entities || {});
    const hashtags = entities.hashtags;
    if (hashtags && hashtags.length > 0) {
        lines.push("  <hashtags>");
        for (const ht of hashtags) {
            if (ht.text)
                lines.push(`    <hashtag>${xmlEscape(ht.text)}</hashtag>`);
        }
        lines.push("  </hashtags>");
    }
    // Entities: mentions
    const mentions = entities.user_mentions;
    if (mentions && mentions.length > 0) {
        lines.push("  <mentions>");
        for (const m of mentions) {
            if (m.screen_name)
                lines.push(`    <mention screen_name="${xmlEscape(m.screen_name)}" />`);
        }
        lines.push("  </mentions>");
    }
    // Entities: links (expanded URLs)
    const urls = entities.urls;
    if (urls && urls.length > 0) {
        lines.push("  <links>");
        for (const u of urls) {
            lines.push(`    <link display="${xmlEscape(u.display_url || "")}" expanded="${xmlEscape(u.expanded_url || "")}" />`);
        }
        lines.push("  </links>");
    }
    // Media counts
    if (meta.image_count)
        add("image_count", meta.image_count);
    if (meta.has_video)
        add("has_video", "true");
    if (meta.sensitive || meta.possibly_sensitive)
        add("sensitive", "true");
    lines.push(`</twitterpost>`);
    try {
        fs_1.default.writeFileSync(nfoPath, lines.join("\n") + "\n", "utf8");
        logger.info(`Wrote Twitter Post.nfo: ${nfoPath}`);
    }
    catch (err) {
        logger.warn(`Failed to write Twitter Post.nfo: ${err}`);
    }
}
// =========================================
// NFO Sidecar Generation (generic)
// =========================================
/**
 * Scan the output directory for downloaded .json metadata files
 * and generate .nfo sidecars for media managers.
 */
function writeNfoFromMetadata(metaJsonPath, sourceUrl, logger) {
    try {
        const raw = fs_1.default.readFileSync(metaJsonPath, "utf8");
        const meta = JSON.parse(raw);
        // Find the corresponding media file
        const dir = path_1.default.dirname(metaJsonPath);
        const baseName = path_1.default.basename(metaJsonPath, ".json");
        const nfoPath = path_1.default.join(dir, baseName + ".nfo");
        const title = meta.title || meta.filename || baseName;
        const lines = [
            `<?xml version="1.0" encoding="UTF-8"?>`,
            `<episodedetails>`,
            `  <title>${xmlEscape(String(title))}</title>`,
            `  <url>${xmlEscape(sourceUrl)}</url>`,
        ];
        const add = (tag, value) => {
            if (value !== undefined && value !== null && value !== "" && value !== "NA") {
                lines.push(`  <${tag}>${xmlEscape(String(value))}</${tag}>`);
            }
        };
        add("plot", meta.description || meta.content);
        add("studio", meta.uploader || meta.user || meta.author);
        add("channel", meta.category);
        add("subcategory", meta.subcategory);
        add("uniqueid", meta.id);
        add("source", meta.category);
        if (meta.date) {
            const d = String(meta.date);
            if (d.length >= 10) {
                add("aired", d.slice(0, 10));
            }
        }
        // Tags
        const tags = meta.tags || meta.tag_string;
        if (Array.isArray(tags)) {
            for (const tag of tags.slice(0, 30)) {
                add("tag", tag);
            }
        }
        else if (typeof tags === "string") {
            for (const tag of tags.split(" ").slice(0, 30)) {
                if (tag)
                    add("tag", tag);
            }
        }
        // Score / rating
        if (typeof meta.score === "number") {
            add("rating", meta.score);
        }
        // Dimensions
        if (meta.width && meta.height) {
            add("resolution", `${meta.width}x${meta.height}`);
        }
        // Site tag
        try {
            const host = new URL(sourceUrl).hostname.replace(/^www\./, "");
            const siteName = host.split(".")[0];
            if (siteName)
                add("tag", siteName);
        }
        catch {
            // invalid URL
        }
        lines.push(`</episodedetails>`);
        fs_1.default.writeFileSync(nfoPath, lines.join("\n") + "\n", "utf8");
        logger.info(`Wrote NFO: ${nfoPath}`);
    }
    catch (err) {
        logger.warn(`Failed to generate NFO from ${metaJsonPath}: ${err}`);
    }
}
// =========================================
// OAuth Action Handlers
// =========================================
/**
 * Run a gallery-dl OAuth flow and capture the output token.
 */
async function runOAuthFlow(site, logger) {
    const oauthCmd = site.includes(":")
        ? `gallery-dl oauth:${site}`
        : `gallery-dl oauth:${site}`;
    logger.info(`Starting OAuth flow: ${oauthCmd}`);
    logger.info("A browser window should open for authorization...");
    try {
        // Run with a generous timeout for user interaction
        const { stdout, stderr } = await execAsync(oauthCmd, { timeout: 300000 });
        const output = stdout + "\n" + stderr;
        logger.info(`OAuth output: ${output}`);
        // Extract refresh token from output
        // gallery-dl outputs the token in various formats depending on the site
        const tokenMatch = output.match(/refresh[_-]token\s*[:=]\s*["']?(\S+?)["']?\s*$/m) ||
            output.match(/access[_-]token\s*[:=]\s*["']?(\S+?)["']?\s*$/m) ||
            output.match(/token\s*[:=]\s*["']?(\S+?)["']?\s*$/m);
        if (tokenMatch) {
            return {
                success: true,
                token: tokenMatch[1],
                message: `OAuth successful. Token obtained.`,
                rawOutput: output,
            };
        }
        // Even without a parseable token, the flow may have succeeded
        // (some sites write directly to the cache)
        return {
            success: true,
            message: `OAuth flow completed. Check output: ${output.slice(0, 200)}`,
            rawOutput: output,
        };
    }
    catch (error) {
        const err = error;
        const errorOutput = err.stderr || err.stdout || err.message;
        // If timed out, it's likely waiting for user interaction
        if (err.message?.includes("TIMEOUT") || err.message?.includes("timed out")) {
            return {
                success: false,
                message: "OAuth flow timed out. Please run the following command in your terminal manually:\n" +
                    `  ${oauthCmd}\n` +
                    "Then paste the resulting token into the settings field above.",
            };
        }
        return {
            success: false,
            message: `OAuth failed: ${errorOutput}`,
        };
    }
}
// =========================================
// Plugin
// =========================================
const plugin = definePlugin({
    name: "gallery-dl",
    version: "1.0.0",
    description: "Download images and media from Pixiv, Twitter, Instagram, DeviantArt, Danbooru, " +
        "ExHentai, Patreon, Kemono, and 400+ other sites using gallery-dl",
    author: "TheArchiver",
    urlPatterns: sites_1.urlPatterns,
    settings: settings_1.pluginSettings,
    actions: {
        // ── Pixiv OAuth ──
        async pixiv_authenticate({ settings, logger }) {
            const result = await runOAuthFlow("pixiv", logger);
            if (result.success && result.token) {
                return {
                    success: true,
                    message: `Pixiv authenticated! Refresh token saved.`,
                    settingsUpdates: [
                        { key: "pixiv_refresh_token", value: result.token },
                    ],
                };
            }
            return {
                success: result.success,
                message: result.message,
            };
        },
        // ── DeviantArt OAuth ──
        async deviantart_authenticate({ settings, logger }) {
            const result = await runOAuthFlow("deviantart", logger);
            if (result.success && result.token) {
                return {
                    success: true,
                    message: `DeviantArt authenticated! Refresh token saved.`,
                    settingsUpdates: [
                        { key: "deviantart_refresh_token", value: result.token },
                    ],
                };
            }
            return {
                success: result.success,
                message: result.message,
            };
        },
        // ── Flickr OAuth ──
        async flickr_authenticate({ settings, logger }) {
            const result = await runOAuthFlow("flickr", logger);
            if (result.success && result.token) {
                // Flickr returns both access-token and access-token-secret
                const output = result.rawOutput || result.message;
                const secretMatch = output.match(/access[_-]token[_-]secret\s*[:=]\s*["']?(\S+?)["']?\s*$/m);
                const updates = [
                    { key: "flickr_access_token", value: result.token },
                ];
                if (secretMatch) {
                    updates.push({ key: "flickr_access_token_secret", value: secretMatch[1] });
                }
                return {
                    success: true,
                    message: `Flickr authenticated!`,
                    settingsUpdates: updates,
                };
            }
            return {
                success: result.success,
                message: result.message,
            };
        },
        // ── Tumblr OAuth ──
        async tumblr_authenticate({ settings, logger }) {
            const result = await runOAuthFlow("tumblr", logger);
            if (result.success && result.token) {
                return {
                    success: true,
                    message: `Tumblr authenticated!`,
                    settingsUpdates: [
                        { key: "tumblr_access_token", value: result.token },
                    ],
                };
            }
            return {
                success: result.success,
                message: result.message,
            };
        },
    },
    async download(context) {
        const { url, rootDirectory, helpers, logger, settings } = context;
        logger.info(`Starting gallery-dl download for: ${url}`);
        if (parseRedditUrl(url)) {
            logger.info("Reddit URL detected; using direct Reddit downloader instead of gallery-dl");
            return handleDirectRedditDownload(context);
        }
        // ── Read settings ──
        const baseFolder = getBaseFolder(settings);
        const legacyLibraryFolder = getSetting(settings, "library_folder");
        if (!getSetting(settings, "save_directory") && legacyLibraryFolder) {
            try {
                await settings.set("save_directory", legacyLibraryFolder);
                logger.info(`Migrated legacy library_folder to save_directory: ${legacyLibraryFolder}`);
            }
            catch (err) {
                logger.warn(`Failed to migrate legacy library_folder setting: ${err}`);
            }
        }
        // ── Resolve output directory ──
        const outputDir = resolveOutputDir(url, rootDirectory, baseFolder, settings, logger);
        await helpers.io.ensureDir(outputDir);
        // ── Verify gallery-dl is available ──
        try {
            const { stdout } = await execAsync("gallery-dl --version");
            logger.info(`gallery-dl version: ${stdout.trim()}`);
        }
        catch {
            return {
                success: false,
                message: "gallery-dl is not installed or not in PATH. " +
                    "Install via: pip install gallery-dl (or pipx install gallery-dl)",
            };
        }
        // ── Build configuration ──
        const generatedConfig = buildConfig(settings, outputDir, logger);
        // Merge with custom config if provided
        const customConfigPath = getSetting(settings, "custom_config");
        let finalConfig = generatedConfig;
        if (customConfigPath) {
            try {
                const customRaw = fs_1.default.readFileSync(customConfigPath, "utf8");
                const customConfig = JSON.parse(customRaw);
                finalConfig = mergeConfigs(generatedConfig, customConfig);
                logger.info("Merged custom config file with generated settings");
            }
            catch (err) {
                logger.warn(`Failed to read custom config: ${err}. Using generated config only.`);
            }
        }
        // Write config to temp file
        const configDir = path_1.default.join(outputDir, ".gallery-dl-plugin");
        await helpers.io.ensureDir(configDir);
        const configPath = path_1.default.join(configDir, "config.json");
        fs_1.default.writeFileSync(configPath, JSON.stringify(finalConfig, null, 2), "utf8");
        logger.info(`Wrote gallery-dl config: ${configPath}`);
        // ── Build command ──
        const args = [];
        // Use our generated config alongside the global config
        // (--config-ignore skips global, then --config loads ours)
        args.push("--config-ignore", "--config", shellEscape(configPath));
        // Verbose logging if enabled
        if (getBoolSetting(settings, "verbose", false)) {
            args.push("--verbose");
        }
        // Extra user-specified arguments
        const extraArgs = getSetting(settings, "extra_args");
        if (extraArgs) {
            args.push(extraArgs);
        }
        // The URL to download
        args.push(shellEscape(url));
        const command = `gallery-dl ${args.join(" ")}`;
        logger.info(`Running: ${command}`);
        try {
            const { stdout, stderr } = await execAsync(command);
            // Log gallery-dl output
            if (stdout) {
                const lines = stdout.split("\n").filter(Boolean);
                let downloadCount = 0;
                let skipCount = 0;
                for (const line of lines) {
                    if (line.startsWith("#")) {
                        // gallery-dl outputs filenames prefixed with #
                        downloadCount++;
                        logger.info(`Downloaded: ${line.substring(1).trim()}`);
                    }
                    else if (line.includes("skipping")) {
                        skipCount++;
                    }
                    else {
                        logger.info(line);
                    }
                }
                logger.info(`Downloads: ${downloadCount}, Skipped: ${skipCount}`);
            }
            if (stderr) {
                for (const line of stderr.split("\n").filter(Boolean)) {
                    if (line.includes("WARNING") || line.includes("warning")) {
                        logger.warn(line);
                    }
                    else if (line.includes("ERROR") || line.includes("error")) {
                        logger.error(line);
                    }
                    else {
                        logger.info(line);
                    }
                }
            }
            // Social media enrichment: convert gallery-dl metadata to Post.nfo + fetch comments/replies
            const socialPlatform = detectSocialPlatform(url);
            if (socialPlatform && getBoolSetting(settings, "write_metadata", true)) {
                try {
                    await enrichSocialMetadata(outputDir, url, socialPlatform, logger);
                }
                catch (err) {
                    logger.warn(`Social metadata enrichment error: ${err}`);
                }
            }
            // Generate NFO sidecars if enabled
            if (getBoolSetting(settings, "write_info_nfo", false) && getBoolSetting(settings, "write_metadata", true)) {
                try {
                    const jsonFiles = await findJsonMetadata(outputDir);
                    for (const jsonFile of jsonFiles) {
                        const nfoFile = jsonFile.replace(/\.json$/, ".nfo");
                        if (!fs_1.default.existsSync(nfoFile)) {
                            writeNfoFromMetadata(jsonFile, url, logger);
                        }
                    }
                }
                catch (err) {
                    logger.warn(`NFO generation error: ${err}`);
                }
            }
            return {
                success: true,
                message: `Downloaded to ${outputDir}`,
            };
        }
        catch (error) {
            const err = error;
            const errorOutput = sanitizeGalleryDlErrorOutput(err.stderr || err.stdout || err.message);
            // gallery-dl exit code 1 can mean "no extractor found"
            if (errorOutput.includes("No suitable extractor")) {
                logger.error(`No gallery-dl extractor found for: ${url}`);
                return {
                    success: false,
                    message: `No gallery-dl extractor found for this URL. The site may not be supported, or the URL format may be incorrect.`,
                };
            }
            // Authentication errors
            if (errorOutput.includes("401") ||
                errorOutput.includes("403") ||
                errorOutput.includes("authentication") ||
                errorOutput.includes("login")) {
                logger.error(`Authentication required: ${errorOutput}`);
                return {
                    success: false,
                    message: `Authentication required for this URL. ` +
                        `Please configure credentials in the plugin settings. ` +
                        `Error: ${errorOutput.slice(0, 300)}`,
                };
            }
            if (errorOutput.includes("Reddit blocked the request with its network security page")) {
                logger.error(errorOutput);
                return {
                    success: false,
                    message: "Reddit blocked the request with its network security page. " +
                        "This is not macOS-specific. Try browser cookies or Reddit API credentials, " +
                        "and avoid proxies/VPNs or IPs Reddit distrusts.",
                };
            }
            // Some content was downloaded before the error
            if (err.stdout && (err.stdout.includes("#") || err.stdout.includes("/"))) {
                const downloadedLines = err.stdout.split("\n").filter((l) => l.startsWith("#") || l.startsWith("/"));
                const downloaded = downloadedLines.length;
                logger.warn(`Partial download: ${downloaded} files before error`);
                // Log the actual error from stderr
                if (err.stderr) {
                    for (const line of err.stderr.split("\n").filter(Boolean)) {
                        // Skip Python warnings (InsecureRequestWarning etc.)
                        if (line.includes("Warning:") || line.includes("warnings.warn"))
                            continue;
                        logger.warn(line);
                    }
                }
                // Still run social enrichment on partial downloads
                const socialPlatform = detectSocialPlatform(url);
                if (socialPlatform && getBoolSetting(settings, "write_metadata", true)) {
                    try {
                        await enrichSocialMetadata(outputDir, url, socialPlatform, logger);
                    }
                    catch (enrichErr) {
                        logger.warn(`Social metadata enrichment error: ${enrichErr}`);
                    }
                }
                return {
                    success: true,
                    message: `Partial download: ${downloaded} files downloaded before error. Check logs for details.`,
                };
            }
            logger.error(`gallery-dl failed: ${errorOutput}`);
            return {
                success: false,
                message: `gallery-dl failed: ${errorOutput.slice(0, 500)}`,
            };
        }
    },
});
/**
 * Recursively find .json metadata files in a directory.
 */
async function findJsonMetadata(dir) {
    const results = [];
    try {
        const entries = fs_1.default.readdirSync(dir, { withFileTypes: true });
        for (const entry of entries) {
            const fullPath = path_1.default.join(dir, entry.name);
            if (entry.isDirectory() && entry.name !== ".gallery-dl-plugin") {
                results.push(...(await findJsonMetadata(fullPath)));
            }
            else if (entry.isFile() && entry.name.endsWith(".json") && !entry.name.startsWith(".")) {
                results.push(fullPath);
            }
        }
    }
    catch {
        // Directory read error, skip
    }
    return results;
}
exports.default = plugin;
