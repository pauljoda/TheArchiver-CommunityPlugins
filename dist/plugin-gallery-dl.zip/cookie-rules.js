"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveCookieFileForUrl = resolveCookieFileForUrl;
function getSetting(settings, key) {
    const raw = settings.get(key);
    if (!raw || raw === "null" || raw === "undefined" || raw === "none")
        return "";
    return String(raw).trim();
}
function hostnameMatchesDomain(hostname, domain) {
    return hostname === domain || hostname.endsWith("." + domain);
}
function resolveCookieFileForUrl(settings, url, logger) {
    const globalCookiesFile = getSetting(settings, "cookies_file");
    const rawSiteCookies = getSetting(settings, "site_cookies");
    if (!rawSiteCookies)
        return globalCookiesFile;
    let hostname;
    try {
        hostname = new URL(url).hostname.toLowerCase();
    }
    catch {
        return globalCookiesFile;
    }
    let siteCookies;
    try {
        siteCookies = JSON.parse(rawSiteCookies);
    }
    catch {
        logger?.warn("site_cookies setting is not valid JSON, using global cookies file");
        return globalCookiesFile;
    }
    const matchingRule = Object.entries(siteCookies)
        .map(([domain, cookiesFile]) => ({
        domain: domain.trim().toLowerCase(),
        cookiesFile: typeof cookiesFile === "string" ? cookiesFile.trim() : "",
    }))
        .filter((rule) => rule.domain && rule.cookiesFile)
        .sort((a, b) => b.domain.length - a.domain.length)
        .find((rule) => hostnameMatchesDomain(hostname, rule.domain));
    return matchingRule?.cookiesFile || globalCookiesFile;
}
